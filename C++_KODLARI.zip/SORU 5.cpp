#include <iostream>
#include <cmath>
using namespace std;
main()
{ 
double  a11,a12,a13,a14,a15,a21,a22,a23,a24,a25,a31,a32,a33,a34,a35,a41,a42,a43,a44,a45,a51,a52,a53,a54,a55;
double diz;
cout << "A11 degerini giriniz: ";
cin >> a11;
cout << "A12 degerini giriniz: ";
cin >> a12;
cout << "A13 degerini giriniz: ";
cin >> a13;
cout << "A14 degerini giriniz: ";
cin >> a14;
cout << "A15 degerini giriniz: ";
cin >> a15;
cout << "A21 degerini giriniz: ";
cin >> a21;
cout << "A22 degerini giriniz: ";
cin >> a22;
cout << "A23 degerini giriniz: ";
cin >> a23;
cout << "A24 degerini giriniz: ";
cin >> a24;
cout << "A25 degerini giriniz: ";
cin >> a25;
cout << "A31 degerini giriniz: ";
cin >> a31;
cout << "A32 degerini giriniz: ";
cin >> a32;
cout << "A33 degerini giriniz: ";
cin >> a33;
cout << "A34 degerini giriniz: ";
cin >> a34;
cout << "A35 degerini giriniz: ";
cin >> a35;
cout << "A41 degerini giriniz: ";
cin >> a41;
cout << "A42 degerini giriniz: ";
cin >> a42;
cout << "A43 degerini giriniz: ";
cin >> a43;
cout << "A44 degerini giriniz: ";
cin >> a44;
cout << "A45 degerini giriniz: ";
cin >> a45;
cout << "A51 degerini giriniz: ";
cin >> a51;
cout << "A52 degerini giriniz: ";
cin >> a52;
cout << "A53 degerini giriniz: ";
cin >> a53;
cout << "A54 degerini giriniz: ";
cin >> a54;
cout << "A55 degerini giriniz: ";
cin >> a55;
{

double diz;
 diz=sqrt(pow(a11,2)+pow(a12,2)+pow(a13,2)+pow(a14,2)+pow(a15,2)+pow(a21,2)+pow(a22,2)+pow(a23,2)+pow(a24,2)+pow(a25,2)+pow(a31,2)+pow(a32,2)+pow(a33,2)+pow(a34,2)+pow(a35,2)+pow(a41,2)+pow(a42,2)+pow(a43,2)+pow(a44,2)+pow(a45,2)+pow(a51,2)+pow(a52,2)+pow(a53,2)+pow(a54,2)+pow(a55,2));
cout << "A Matrisinin Oklid Normu: " << diz <<  endl;
}
return 0;}

